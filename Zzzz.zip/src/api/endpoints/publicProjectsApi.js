import { apiSlice } from "../apiSlice";

export const publicProjectsApi =
  apiSlice.injectEndpoints({
    endpoints: (builder) => ({


      //مشاريع المعرض للمستخدمين 
      getUserPublicProjects:builder.query({
      query: (sector) => {
        const params = sector && sector !== "all" ? `?sector=${sector}` : "";
        return `/ideas/exhibition-projects/${params}`;
      },
      providesTags: ['PublicProjects'],
    }),

    //تفاصيل مشروع المعرض لصفحة التفاصيل
    getProjectDetails: builder.query({
      query: (id) => `/ideas/projects/${id}/`, 
      providesTags: (result, error, id) => [{ type: "PublicProjects", id }],
    }),


      // جلب مشروع واحد للعرض العام
      getPublicProjectById:
        builder.query({
          query: (id) =>
            `admin/ideas/${id}/details/`,
          providesTags: [
            "PublicProjects",
          ],
        }),

      // جلب كل المشاريع
      getPublicProjects:
        builder.query({
          query: () =>
            `admin/incubations/graduated-projects/`,
          providesTags: [
            "PublicProjects",
          ],
        }),

      // المشاريع المحتضنة للإدارة
      getIncubatedProjects:
        builder.query({
          query: () =>
            `/admin/incubations/projects`,
          providesTags: [
            "PublicProjects",
          ],
        }),

      //  المقيمين الحاليين للمشروع المحتضن
      getIncubationEvaluators:
        builder.query({
          query: (
            projectId
          ) =>
            `/admin/incubations/ideas/${projectId}/mentors/`,
        }),

        
      getGraduatedpublicProjects: builder.query({
  query: () =>
    "admin/exhibition/publicprojects/graduated/",
  providesTags: [
    "Projects",
  ],
}),
      // تعيين مقيمين احتضان
      assignIncubationEvaluators:
        builder.mutation({
          query: ({
            idea_id,
            mentor_user_ids,
          }) => ({
            url:
              `/admin/incubations/ideas/${idea_id}/mentors/assign/`,
            method:
              "POST",
            body: {
              mentor_user_ids:
                Array.isArray(
                  mentor_user_ids
                )
                  ? mentor_user_ids
                  : [],
            },
          }),
        }),
    }),
  });

export const {
  useGetUserPublicProjectsQuery,
  useGetProjectDetailsQuery,
  useGetPublicProjectByIdQuery,
  useGetPublicProjectsQuery,
  useGetIncubatedProjectsQuery,
  useGetIncubationEvaluatorsQuery,
  useAssignIncubationEvaluatorsMutation,
  useGetGraduatedpublicProjectsQuery,
} = publicProjectsApi;