import { apiSlice } from "../../apiSlice";

export const graduationApi = apiSlice.injectEndpoints({
  endpoints: (builder) => ({
    
    getIncubationNotes: builder.query({
      query: (idea_id) => ({
        url: `/admin/incubations/ideas/${idea_id}/latest-review/`,
        method: "GET",
      }),
     
      providesTags: ["EvaluationNotes"],
    }),
    

  submitGraduationDecision: builder.mutation({
  query: ({ idea_id, status,}) => ({
    url: `/admin/incubations/ideas/${idea_id}/graduate/`,
    method: 'POST',
    body: { action: status},
  }),

  
  invalidatesTags: (result, error, { idea_id }) => [{ type: 'GraduatedProjects', id: idea_id }],
}),

    getGraduatedProjects: builder.query({
      query: () => ({
        url: `/admin/incubations/graduated-projects/`, 
        method: 'GET',
      }),
    
      providesTags: ['GraduatedProjects'], 
    }),

  }),
});

export const {
  useGetIncubationNotesQuery,
  useSubmitGraduationDecisionMutation,
  useGetGraduatedProjectsQuery,
} = graduationApi;