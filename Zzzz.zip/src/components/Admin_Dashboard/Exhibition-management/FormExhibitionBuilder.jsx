
import React, { useState, useEffect } from "react";
import FieldTypesPanel from "../Exhibition-management/FieldTypesPanel";
import FormBuilderCanvas from "../Exhibition-management/FormBuilderCanvas";
import Button from "../../Button";
import { useNavigate } from "react-router-dom";
import { showError } from "../../../Utils/toast";

const FormExhibitionBuilder = ({ onSubmit, isSubmitting = false, initialFields = [], onFieldsChange, seasonData }) => {
  console.log("INCUBATION FORM BUILDER");
  const navigate = useNavigate();
  const [fields, setFields] = useState(initialFields);
  const [isPublishing, setIsPublishing] = useState(false);
    const goToPreview = () => {
  navigate("/admin/preview-form", {
    state: {
      fields,
      seasonData,
      returnTab: "create-card", // مهم
    },
  });
};
  
  useEffect(() => {
    if (onFieldsChange) onFieldsChange(fields);
  }, [fields, onFieldsChange]);

  // إضافة حقل جديد
  const addField = (type) => {
  const newField = {
    id: crypto.randomUUID(),
    type,
    label: "",
    required: false,

    options: [
      "single_choice",
      "multiple_choice",
    ].includes(type)
      ? []
      : null,
  };

  setFields((prev) => [
    ...prev,
    newField,
  ]);
};

  // تعديل حقل
  const updateField = (id, updatedData) => {
    setFields((prev) =>
      prev.map((field) =>
        field.id === id ? { ...field, ...updatedData } : field
      )
    );
  };

  // حذف حقل
  const deleteField = (id) => {
    setFields((prev) => prev.filter((field) => field.id !== id));
  };

  // نشر النموذج (إرسال التصميم إلى الباك عبر الـ prop)
  const publishForm = async () => {
    if (!fields.length) {
      showError("يرجى إضافة حقل واحد على الأقل قبل النشر.");
      return;
    }

    // تحقق من أن كل الحقول لها تسمية (label)
    const emptyLabel = fields.find((f) => !f.label.trim());
    if (emptyLabel) {
      showError("يرجى إدخال تسمية لجميع الحقول.");
      return;
    }

    setIsPublishing(true);
    try {
      // تحويل الحقول إلى الشكل الذي يتوقعه الباك (إذا لزم)
      

const formConfig = {
  questions: fields.map((field) => ({
    id: field.id,
    type: field.type,
    label: field.label,
    required: field.required,

    options:
      field.options?.map((opt) => ({
        label:
          typeof opt === "string"
            ? opt
            : opt.label,
      })) || [],
  })),
};
      await onSubmit(formConfig);
    } catch (err) {
      console.error(err);
      showError(err?.data?.message || "حدث خطأ في نشر النموذج.");
    } finally {
      setIsPublishing(false);
    }
  };


 return (
    <div className="w-full overflow-hidden">
      
      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-6 w-full">
        
        {/* منطقة بناء النموذج */}
        <div className="w-full">
          <FormBuilderCanvas
            fields={fields}
            updateField={updateField}
            deleteField={deleteField}
          />
        </div>

        {/* لوحة أنواع الحقول */}
        <div className="w-full md:w-auto">
          <FieldTypesPanel addField={addField} />
        </div>
      </div>

      <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mt-8 w-full">
        <Button
          label="معاينة النموذج"
          onClick={goToPreview}
          className="bg-main-color w-full sm:w-50"
          disabled={isSubmitting || isPublishing}
        />
        <Button
          label={isPublishing ? "جاري النشر..." : "نشر"}
          onClick={publishForm}
          className="bg-main-color w-full sm:w-50"
          disabled={isSubmitting || isPublishing}
        />
      </div>
    </div>
  );
};
export default FormExhibitionBuilder;