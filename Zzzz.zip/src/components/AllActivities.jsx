import React from 'react'
import ActivityCard from '../components/ActivityCard';
import NavLinkUniversal from './NavLinkUniversal';

const AllActivities = ({ activities }) => {
 return (
  <div className="w-full px-4 md:px-0">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {activities.map((activity) => (
        // إضافة flex و min-w-0 تمنع المتصفح من توسيع البطاقة أكثر من حجم العمود
        <div key={activity.id} className="flex min-w-0">
          <div className="w-full flex-shrink-0">
            <ActivityCard
              image={activity.image}
              title={activity.title}
              description={activity.description}
              status={activity.status}
              trainer_name={activity.trainer_name}
              capacity={activity.capacity}
            >
              {/* إضافة break-all للزر تضمن أنه إذا كان النص طويلاً سيتم كسره لسطر جديد بدل التمدد */}
              <div className="mt-4 w-full">
                <NavLinkUniversal
                  label="عرض التفاصيل"
                  to={`/public-workshops/${activity.id}`}
                  className="block w-full text-center bg-main-color text-white rounded py-2 hover:bg-second-color transition break-all"
                />
              </div>
            </ActivityCard>
          </div>
        </div>
      ))}
    </div>
  </div>
);
}

export default AllActivities